import 'bootstrap';

// or get all of the named exports for further usage
import * as bootstrap from 'bootstrap';